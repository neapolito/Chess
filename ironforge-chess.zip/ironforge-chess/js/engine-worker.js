/*  IronForge built-in engine ("Ironclad")
    Iterative-deepening alpha-beta with quiescence, check extension,
    MVV-LVA + killer + history ordering, PV ordering, multi-PV and
    tapered PeSTO-style evaluation. Runs inside a Web Worker.          */
importScripts('chess.js');

const VAL = { p: 100, n: 320, b: 335, r: 500, q: 950, k: 0 };
const PHASE = { p: 0, n: 1, b: 1, r: 2, q: 4, k: 0 };

// Piece-square tables (white's view, a8..h8 first row). [middlegame, endgame]
const PST = {
  p: [[0,0,0,0,0,0,0,0, 98,134,61,95,68,126,34,-11, -6,7,26,31,65,56,25,-20, -14,13,6,21,23,12,17,-23, -27,-2,-5,12,17,6,10,-25, -26,-4,-4,-10,3,3,33,-12, -35,-1,-20,-23,-15,24,38,-22, 0,0,0,0,0,0,0,0],
      [0,0,0,0,0,0,0,0, 178,173,158,134,147,132,165,187, 94,100,85,67,56,53,82,84, 32,24,13,5,-2,4,17,17, 13,9,-3,-7,-7,-8,3,-1, 4,7,-6,1,0,-5,-1,-8, 13,8,8,10,13,0,2,-7, 0,0,0,0,0,0,0,0]],
  n: [[-167,-89,-34,-49,61,-97,-15,-107, -73,-41,72,36,23,62,7,-17, -47,60,37,65,84,129,73,44, -9,17,19,53,37,69,18,22, -13,4,16,13,28,19,21,-8, -23,-9,12,10,19,17,25,-16, -29,-53,-12,-3,-1,18,-14,-19, -105,-21,-58,-33,-17,-28,-19,-23],
      [-58,-38,-13,-28,-31,-27,-63,-99, -25,-8,-25,-2,-9,-25,-24,-52, -24,-20,10,9,-1,-9,-19,-41, -17,3,22,22,22,11,8,-18, -18,-6,16,25,16,17,4,-18, -23,-3,-1,15,10,-3,-20,-22, -42,-20,-10,-5,-2,-20,-23,-44, -29,-51,-23,-15,-22,-18,-50,-64]],
  b: [[-29,4,-82,-37,-25,-42,7,-8, -26,16,-18,-13,30,59,18,-47, -16,37,43,40,35,50,37,-2, -4,5,19,50,37,37,7,-2, -6,13,13,26,34,12,10,4, 0,15,15,15,14,27,18,10, 4,15,16,0,7,21,33,1, -33,-3,-14,-21,-13,-12,-39,-21],
      [-14,-21,-11,-8,-7,-9,-17,-24, -8,-4,7,-12,-3,-13,-4,-14, 2,-8,0,-1,-2,6,0,4, -3,9,12,9,14,10,3,2, -6,3,13,19,7,10,-3,-9, -12,-3,8,10,13,3,-7,-15, -14,-18,-7,-1,4,-9,-15,-27, -23,-9,-23,-5,-9,-16,-5,-17]],
  r: [[32,42,32,51,63,9,31,43, 27,32,58,62,80,67,26,44, -5,19,26,36,17,45,61,16, -24,-11,7,26,24,35,-8,-20, -36,-26,-12,-1,9,-7,6,-23, -45,-25,-16,-17,3,0,-5,-33, -44,-16,-20,-9,-1,11,-6,-71, -19,-13,1,17,16,7,-37,-26],
      [13,10,18,15,12,12,8,5, 11,13,13,11,-3,3,8,3, 7,7,7,5,4,-3,-5,-3, 4,3,13,1,2,1,-1,2, 3,5,8,4,-5,-6,-8,-11, -4,0,-5,-1,-7,-12,-8,-16, -6,-6,0,2,-9,-9,-11,-3, -9,2,3,-1,-5,-13,4,-20]],
  q: [[-28,0,29,12,59,44,43,45, -24,-39,-5,1,-16,57,28,54, -13,-17,7,8,29,56,47,57, -27,-27,-16,-16,-1,17,-2,1, -9,-26,-9,-10,-2,-4,3,-3, -14,2,-11,-2,-5,2,14,5, -35,-8,11,2,8,15,-3,1, -1,-18,-9,10,-15,-25,-31,-50],
      [-9,22,22,27,27,19,10,20, -17,20,32,41,58,25,30,0, -20,6,9,49,47,35,19,9, 3,22,24,45,57,40,57,36, -18,28,19,47,31,34,39,23, -16,-27,15,6,9,17,10,5, -22,-23,-30,-16,-16,-23,-36,-32, -33,-28,-22,-43,-5,-32,-20,-41]],
  k: [[-65,23,16,-15,-56,-34,2,13, 29,-1,-20,-7,-8,-4,-38,-29, -9,24,2,-16,-20,6,22,-22, -17,-20,-12,-27,-30,-25,-14,-36, -49,-1,-27,-39,-46,-44,-33,-51, -14,-14,-22,-46,-44,-30,-15,-27, 1,7,-8,-64,-43,-16,9,8, -15,36,12,-54,8,-28,24,14],
      [-74,-35,-18,-18,-11,15,4,-17, -12,17,14,17,17,38,23,11, 10,17,23,15,20,45,44,13, -8,22,24,27,26,33,26,3, -18,-4,21,24,27,23,9,-11, -19,-3,11,21,23,16,7,-9, -27,-11,4,13,14,4,-5,-17, -53,-34,-21,-11,-28,-14,-24,-43]],
};

const MATE = 100000;
let nodes = 0, deadline = 0, stopped = false;
let killers = [], historyTbl = {};

function evaluate(g) {
  let mg = 0, eg = 0, phase = 0, bishops = { w: 0, b: 0 };
  const b = g.board;
  for (let s = 0; s < 120; s++) {
    if (s & 0x88) { s += 7; continue; }
    const p = b[s];
    if (!p) continue;
    const t = p.toLowerCase(), white = p !== t;
    const idx = white ? (s >> 4) * 8 + (s & 7) : (7 - (s >> 4)) * 8 + (s & 7);
    const sign = white ? 1 : -1;
    mg += sign * (VAL[t] + PST[t][0][idx]);
    eg += sign * (VAL[t] + PST[t][1][idx]);
    phase += PHASE[t];
    if (t === 'b') bishops[white ? 'w' : 'b']++;
  }
  if (bishops.w >= 2) { mg += 30; eg += 50; }
  if (bishops.b >= 2) { mg -= 30; eg -= 50; }
  phase = Math.min(phase, 24);
  const score = (mg * phase + eg * (24 - phase)) / 24;
  return (g.turn === 'w' ? score : -score) + 10; // small tempo bonus
}

function orderMoves(moves, ply, pvMove) {
  for (const m of moves) {
    let s = 0;
    if (pvMove && m.from === pvMove.from && m.to === pvMove.to && m.promo === pvMove.promo) s = 1e7;
    else if (m.captured) s = 1e6 + VAL[m.captured.toLowerCase()] * 10 - VAL[m.piece.toLowerCase()] / 10;
    else if (m.promo) s = 9e5;
    else {
      const k = killers[ply];
      if (k && k.some((x) => x && x.from === m.from && x.to === m.to)) s = 8e5;
      else s = historyTbl[m.from * 128 + m.to] || 0;
    }
    m._o = s;
  }
  moves.sort((a, b) => b._o - a._o);
  return moves;
}

function timeUp() {
  if ((nodes & 1023) === 0 && Date.now() > deadline) stopped = true;
  return stopped;
}

function quiesce(g, alpha, beta, ply) {
  nodes++;
  if (timeUp()) return 0;
  const stand = evaluate(g);
  if (stand >= beta) return beta;
  if (stand > alpha) alpha = stand;
  if (ply > 40) return stand;
  const moves = orderMoves(g.legal(true), ply);
  for (const m of moves) {
    // delta pruning
    if (m.captured && !m.promo && stand + VAL[m.captured.toLowerCase()] + 200 < alpha) continue;
    g._make(m);
    const sc = -quiesce(g, -beta, -alpha, ply + 1);
    g._unmake();
    if (stopped) return 0;
    if (sc >= beta) return beta;
    if (sc > alpha) alpha = sc;
  }
  return alpha;
}

function search(g, depth, alpha, beta, ply, pvLine, pvPrev) {
  if (timeUp()) return 0;
  const inCheck = g.inCheck();
  if (inCheck) depth++;
  if (depth <= 0) return quiesce(g, alpha, beta, ply);
  nodes++;
  if (ply > 0 && (g.half >= 100 || g.insufficient() || (g.reps.get(g.posKey()) || 0) >= 2)) return 0;

  const moves = g.legal();
  if (!moves.length) return inCheck ? -MATE + ply : 0;
  orderMoves(moves, ply, pvPrev && pvPrev[ply]);
  let best = -Infinity, first = true;
  for (const m of moves) {
    g._make(m);
    g._countRep(1);
    const child = [];
    let sc;
    if (first) sc = -search(g, depth - 1, -beta, -alpha, ply + 1, child, pvPrev);
    else {
      // late move reduction for quiet moves
      const reduce = depth >= 3 && !m.captured && !m.promo && !inCheck && m._o < 8e5 ? 1 : 0;
      sc = -search(g, depth - 1 - reduce, -alpha - 1, -alpha, ply + 1, child, null);
      if (sc > alpha && sc < beta) sc = -search(g, depth - 1, -beta, -alpha, ply + 1, child, null);
    }
    g._countRep(-1);
    g._unmake();
    if (stopped) return 0;
    first = false;
    if (sc > best) best = sc;
    if (sc > alpha) {
      alpha = sc;
      pvLine.length = 0; pvLine.push(m, ...child);
      if (sc >= beta) {
        if (!m.captured) {
          killers[ply] = [m, (killers[ply] || [])[0]];
          historyTbl[m.from * 128 + m.to] = (historyTbl[m.from * 128 + m.to] || 0) + depth * depth;
        }
        return beta;
      }
    }
  }
  return best;
}

function uci(m) { return Chess.sqName(m.from) + Chess.sqName(m.to) + (m.promo || ''); }

function think(msg) {
  const g = new Chess(msg.fen);
  (msg.history || []).forEach((k) => g.reps.set(k, (g.reps.get(k) || 0) + 1));
  const maxDepth = msg.depth || 64;
  const multipv = Math.max(1, msg.multipv || 1);
  deadline = Date.now() + (msg.movetime || 2000);
  stopped = false; nodes = 0; killers = []; historyTbl = {};
  const t0 = Date.now();
  let rootMoves = g.legal();
  if (!rootMoves.length) { postMessage({ type: 'bestmove', move: null }); return; }
  let results = rootMoves.map((m) => ({ m, score: 0, pv: [m] }));
  let lastGood = results;
  for (let d = 1; d <= maxDepth; d++) {
    const cur = [];
    // sort by previous iteration
    results.sort((a, b) => b.score - a.score);
    let kth = -Infinity;
    for (const r of results) {
      g._make(r.m);
      g._countRep(1);
      const child = [];
      const alpha = cur.length >= multipv ? kth : -Infinity;
      const prev = r.pv.length > 1 ? [null, ...r.pv.slice(1)] : null;
      let sc = -search(g, d - 1, -Infinity, alpha === -Infinity ? Infinity : -alpha, 1, child, prev);
      g._countRep(-1);
      g._unmake();
      if (stopped) break;
      cur.push({ m: r.m, score: sc, pv: [r.m, ...child] });
      cur.sort((a, b) => b.score - a.score);
      if (cur.length >= multipv) kth = cur[multipv - 1].score;
    }
    if (stopped && cur.length < results.length) {
      if (!cur.length) break;
      // merge partial iteration if it found something better
      if (cur[0].score > lastGood[0].score) lastGood = cur.concat(lastGood.filter((x) => !cur.some((c) => c.m === x.m)));
      break;
    }
    results = cur; lastGood = cur;
    const lines = cur.slice(0, multipv).map((r) => ({ score: fmtScore(r.score), pv: r.pv.map(uci) }));
    postMessage({ type: 'info', depth: d, nodes, time: Date.now() - t0, lines });
    if (Math.abs(cur[0].score) > MATE - 200) break;
    if (Date.now() > deadline) break;
  }
  // bot weakness: noise and occasional blunders
  let pick = lastGood[0];
  if (msg.noise) {
    const pool = lastGood.map((r) => ({ r, s: r.score + (Math.random() - 0.5) * 2 * msg.noise }));
    pool.sort((a, b) => b.s - a.s);
    pick = pool[0].r;
  }
  if (msg.blunder && Math.random() < msg.blunder) pick = lastGood[Math.floor(Math.random() * lastGood.length)];
  postMessage({ type: 'bestmove', move: uci(pick.m), score: fmtScore(pick.score), nodes, time: Date.now() - t0 });
}

function fmtScore(sc) {
  if (Math.abs(sc) > MATE - 500) {
    const plies = MATE - Math.abs(sc);
    return { mate: Math.sign(sc) * Math.ceil(plies / 2) };
  }
  return { cp: Math.round(sc) };
}

onmessage = (e) => {
  const msg = e.data;
  if (msg.cmd === 'go') {
    try { think(msg); } catch (err) { postMessage({ type: 'error', error: String(err && err.stack || err) }); }
  }
};
